﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChairHire
{
    class Program
    {
        static void Main(string[] args)
        {
            int N = 5;
            String TYPE_PACKER_STACKER = "PS";
            String TYPE_HIGH_BACK = "HB";
            String TYPE_LECTURE = "L";

            double PACKER_STACKER_PRICE = 5.0;
            double HIGH_BACK_PRICE = 10.50;
            double LECTURE_PRICE = 15.00;

            String[] names = new String[N];
            int[] chairs = new int[N];
            String[] types = new String[N];
            double[] totals = new double[N];

            Console.WriteLine("Welcome to Victoria Chair Hire!");
            for (int i = 0; i < N; i++) {
                Console.Write("\nEnter customer name placing the order: ");
                String name = Console.ReadLine();
                names[i] = name;
                String type = "";
                while (true)
                {
                    Console.Write("Enter type of chair to order Packer Stacker chair (PS) or High Back Chair (HB) or Lecture chair (L)? ");
                    type = Console.ReadLine();
                    if (type.Equals(TYPE_PACKER_STACKER) || type.Equals(TYPE_HIGH_BACK) || type.Equals(TYPE_LECTURE)) {
                        break;
                    }
                    Console.WriteLine("Invalid type. Please select again.");
                }
                types[i] = type;
                int number = 0;
                while(true) { 
                    Console.Write("Enter number of chairs: ");
                    number = Convert.ToInt32(Console.ReadLine());
                    if (number < 20) {
                        Console.WriteLine("You can't place order below 20 chairs!");
                        continue;
                    }
                    if (number > 500) {
                        Console.WriteLine("You can't place order beyoud 500 chairs!");
                        continue;
                    }
                    break;
                }
                chairs[i] = number;
                Console.Write("\n\tOrder total for "+name+" is ");
                double total;
                if (type.Equals(TYPE_PACKER_STACKER)) {
                    total = number * PACKER_STACKER_PRICE;
                } else if (type.Equals(TYPE_HIGH_BACK)) {
                    total = number * HIGH_BACK_PRICE;
                } else {
                    total = number * LECTURE_PRICE;
                }
                if (number >= 100) {
                    total = total - (total * 0.05);
                }
                totals[i] = total;
                Console.WriteLine("$" + String.Format("{0:0.000}", total));
                Console.WriteLine("-----------------------------------------------------------");
            }
            Console.WriteLine("\n\n\tSummry of Chair Hire Orders");
            Console.WriteLine("-----------------------------------------------------------\n");
            Console.WriteLine("  "+String.Format("{0,-20} {1,16} {2,20} {3,15}","Name","Number of Chairs","Chair Types","Order total"));
            int highestIndex = 0, lowestIndex = 0;
            int smallOrders = 0, largeOrders = 0;
            for (int i = 0; i < N; i++) {
                Console.WriteLine("  "+String.Format("{0,-20} {1,16} {2,20} {3,15:$0.00}",names[i],chairs[i],types[i],totals[i]));
                if (totals[i] > totals[highestIndex]) {
                    highestIndex = i;
                }

                if (totals[i] < totals[lowestIndex])
                {
                    lowestIndex = i;
                }
                if (chairs[i] < 100)
                {
                    smallOrders++;
                }
                else {
                    largeOrders++;
                }

            }
            
            Console.WriteLine("\n-----------------------------------------------------------\n");
            Console.WriteLine("Chair order with highest order cost by customer " + names[highestIndex] + " for $" + String.Format("{0:0.00}",totals[highestIndex]) + "\n");
            Console.WriteLine("Chair order with lowest order cost by customer " + names[lowestIndex] + " for $" + String.Format("{0:0.00}",totals[lowestIndex]) + "\n");
            Console.Write("Orders with number of chairs < 100: ");
            for (int i = 0; i < smallOrders; i++) {
                Console.Write("x");
            }
            Console.Write("\nOrders with number of chairs >= 100: ");
            for (int i = 0; i < largeOrders; i++)
            {
                Console.Write("x");
            }
            Console.WriteLine("\nPress any key terminate the program!");
            Console.ReadKey();
        }
    }
}
